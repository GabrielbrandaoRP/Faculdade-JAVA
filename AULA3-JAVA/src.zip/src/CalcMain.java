package src;

import java.util.Scanner;

public class CalcMain {
    public static void main(String[] args) {

        Calc c = new Calc();
        Scanner sc = new Scanner(System.in);
        int n1,n2;
        System.out.println("Numero 1");
        n1= sc.nextInt();
        System.out.println("Numero 2");
        n2 = sc.nextInt();
        System.out.print c.somar(n1,n2);
    }
}
