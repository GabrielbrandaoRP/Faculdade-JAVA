package src;

public class Calc {
    int total;

    public int somar(int x, int y){
        total = x + y;
        return total;
    }
}
