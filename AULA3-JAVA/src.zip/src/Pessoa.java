package src;

public class Pessoa {
    int idade;

    public void niver(){
        idade++;
    }
}
